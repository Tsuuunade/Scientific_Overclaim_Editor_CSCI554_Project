# Member 1 presentation handoff

Version 2.0 | October 15 2026

## Completed

Downloaded and audited 100 original training pairs and 563 reserved test pairs. Recovered full abstracts for eight calibration examples. Completed eight AI-reviewed working decisions with exact evidence and explicit reasons. Selected a reproducible 44-candidate training-only acquisition pool. Independent human reviews and model experiments are not complete.

## Main takeaway

A local causal-word replacement is not enough: the complete scientific statement must be supported by the evidence supplied to the editor. Preserve supported strong wording and abstain when substantive details cannot be verified.

## Illustration

Use M1-01: the claim says "is saving lives", while the cohort abstract reports a mortality association and conditional efficacy. Use the exact reviewed output in Eight_Examples.md with the full-context reference passages. Caption: "AI-reviewed calibration illustration; not a measured model result."

M1-06 illustrates preservation of supported stronger wording in rats and mice. M1-03 illustrates abstention: a causal problem is visible, but 128 species is absent from the abstract. None of these selected cases establishes accuracy, retrieval success or human agreement.

## Next steps

Recover and group the other 36 candidate sources, obtain independent human references, freeze eligible splits and compare methods A-D. Forty-four means acquisition candidates, not verified corrections or a completed balanced evaluation set. The 150-250 proposal target is a later stretch goal.

## Suggested spoken update

We downloaded the paired data and recovered complete abstracts for eight calibration examples. We have AI-reviewed decisions explaining when to correct, preserve or abstain. One case shows why fixing a causal phrase is insufficient: a scientific number still cannot be verified from the abstract. We selected 44 training-only candidates for the pilot. Next we will recover sources, validate labels independently and measure correction success and unnecessary edits with verified and automatically selected evidence.
