# Eight reviewed calibration examples

Version 2.0 | October 15 2026

These are completed AI-reviewed working decisions, not independent human gold, model outputs or test results. All eight are development-only. Read the guide and review form before this file if performing an independent first pass.

| ID | Full-source decision | Action | Use |
|---|---|---|---|

| M1-01 | overclaim | revise | causal correction example |
| M1-02 | supported | unchanged | supported control example |
| M1-03 | insufficient_evidence | abstain | abstention example |
| M1-04 | insufficient_evidence | abstain | abstention example |
| M1-05 | overclaim | revise | scope correction example |
| M1-06 | supported | unchanged | supported causal control example |
| M1-07 | supported | unchanged | supported control example |
| M1-08 | overclaim | revise | scope correction example |

Three overclaims include one causal and two scope-only cases. Keep these categories separate in any reported results.

## M1-01 Use of the English urgent referral pathway for suspected cancer and mortality in patients with cancer: cohort study.

Source: https://pubmed.ncbi.nlm.nih.gov/26462713/ | PMID 26462713 | DOI 10.1136/bmj.h5102

Original label: exaggerates. Full-source decision: overclaim. Relationship-only decision: overclaim.

**Original claim**

Use of the urgent referral pathway (often called the two week wait system) by general practices for patients with suspected cancer is saving lives, according to a study in The BMJ this week.

**Decision and why**

The claim asserts a definite lifesaving effect. The cohort abstract reports an association between practice referral propensity and mortality and describes efficacy conditionally. Replace the definite causal assertion with the reported association.

This is the clearest causal-editing illustration. The revision does not promise that referral causes a survival benefit for an individual patient.

**Expected output**

Use of the urgent referral pathway (often called the two week wait system) by general practices for patients with suspected cancer was associated with lower mortality among patients with cancer, according to a study in The BMJ this week.

**Exact reference passages**

> Design: Cohort study. Linked information from the national Cancer Waiting Times database, NHS Exeter database, and National Cancer Register was used to estimate mortality in patients in relation to the propensity of their general practice to use the urgent referral pathway.

Offsets 143 to 417 (end exclusive).

> Participants: 215,284 patients with cancer, diagnosed or first treated in England in 2009 and followed up to 2013.

Offsets 418 to 532 (end exclusive).

> Results: During four years of follow-up, 91,620 deaths occurred, of which 51,606 (56%) occurred within the first year after diagnosis. Two measures of the propensity to use urgent referral, the standardised referral ratio and the detection rate, were associated with reduced mortality. The hazard ratio for the combination of high referral ratio and high detection rate was 0.96 (95% confidence interval 0.94 to 0.99), applying to 16% (n=34,758) of the study population. Patients with cancer who were registered with general practices with the lowest use of urgent referral had an excess mortality (hazard ratio 1.07 (95% confidence interval 1.05 to 1.08); 37% (n=79,416) of the study population). The comparator group for these two hazard ratios was the remaining 47% (n=101,110) of the study population. This result in mortality was consistent for different types of cancer (apart from breast cancer) and with other stratifications of the dataset, and was not sensitive to adjustment for potential confounders and other details of the statistical model.

Offsets 647 to 1702 (end exclusive).

> Conclusions: Use of the urgent referral pathway could be efficacious. General practices that consistently have a low propensity to use urgent referrals could consider increasing the use of this pathway to improve the survival of their patients with cancer.

Offsets 1703 to 1959 (end exclusive).

**Evidence sufficiency**

Supply design, population, mortality results and conclusion. The short aligned conclusion alone cannot support every detail of the longer revision.

**Change from v1**

Keeps the earlier causal decision and makes the evidence boundary explicit.

## M1-02 Patient preference in psychological treatment and associations with self-reported outcome: national cross-sectional survey in England and Wales.

Source: https://pubmed.ncbi.nlm.nih.gov/26768890/ | PMID 26768890 | DOI 10.1186/s12888-015-0702-8

Original label: exaggerates. Full-source decision: supported. Relationship-only decision: supported.

**Original claim**

Meeting patients' preferences for the time and place of their psychological treatment may affect their perception of treatment outcome, a cross-sectional survey by researchers from the Royal College of Psychiatrists and Imperial College London involving 14,587 respondents suggests.

**Decision and why**

The full abstract itself says that assessing and meeting preferences may improve psychological treatment outcomes. The claim retains conditional wording and describes perceived outcomes. The methods verify 14,587 respondents. Under this source-relative task, observational design alone does not require weakening.

We judge fidelity to the abstract, not whether the authors independently proved a causal mechanism. Equally hedged reporting of the source speculation is allowed.

**Expected output**

Meeting patients' preferences for the time and place of their psychological treatment may affect their perception of treatment outcome, a cross-sectional survey by researchers from the Royal College of Psychiatrists and Imperial College London involving 14,587 respondents suggests.

**Exact reference passages**

> Method: Cross-sectional survey of people receiving psychological treatment from 184 NHS services in England and Wales. 14,587 respondents were asked about treatment preferences and the extent to which these were met by their service. They were also asked to rate the extent to which therapy helped them cope with their difficulties.

Offsets 244 to 576 (end exclusive).

> Results: Most patients (12,549-86.0 %, 95 % CI: 85.5-86.6) expressed a preference for at least one aspect of their treatment. Of these, 4,600 (36.7 %, 95 % CI: 35.8-37.5) had at least one preference that was not met. While most patients reported that their preference for appointment times, venue and type of treatment were met, only 1,769 (40.5 %) of the 4,253 that had a preference for gender had it met. People who expressed a preference that was not met reported poorer outcomes than those with a preference that was met (Odds Ratios: appointment times = 0.29, venue = 0.32, treatment type = 0.16, therapist gender = 0.32, language in which treatment was delivered = 0.40).

Offsets 577 to 1254 (end exclusive).

> Conclusions: Most patients who took part in this survey had preferences about their treatment. People who reported preferences that were not met were less likely to state that treatment had helped them with their problems. Routinely assessing and meeting patient preferences may improve the outcomes of psychological treatment.

Offsets 1255 to 1582 (end exclusive).

**Evidence sufficiency**

Include the survey methods and final speculative conclusion, not just the associational result.

**Change from v1**

Resolves needs_discussion to supported under the source-relative rule.

## M1-03 Maternal investment, life histories, and the costs of brain growth in mammals.

Source: https://pubmed.ncbi.nlm.nih.gov/21444808/ | PMID 21444808 | DOI 10.1073/pnas.1019140108

Original label: exaggerates. Full-source decision: insufficient_evidence. Relationship-only decision: overclaim.

**Original claim**

The study of 128 mammal species, including humans, shows that brain growth in babies is determined by the duration of pregnancy and how long they suckle.

**Decision and why**

The association-to-determination change is a causal error. However, the supplied abstract does not verify the count of 128 species. The prior draft appealed to external paper methods that were not supplied to the editor. A complete revision preserving that scientific quantity cannot be certified from this abstract.

Recognizing a local error does not establish support for the whole corrected sentence. Abstain and explain the missing quantity. Do not silently delete the number or borrow unseen methods. Adding methods later would create a new source version requiring reassessment.

**Expected output**

Abstain. No reliable revised claim. Explain the source limitation and keep the original visible separately.

**Exact reference passages**

> In support of the developmental cost hypothesis, we show that evolutionary changes in pre- and postnatal brain growth correlate specifically with duration of the relevant phases of maternal investment (gestation and lactation, respectively).

Offsets 336 to 577 (end exclusive).

**Evidence sufficiency**

The quote establishes the relationship mismatch. The missing-number finding comes from inspecting the entire abstract; absence cannot be represented by an invented quote.

**Change from v1**

Replaces the previous complete correction with abstention; retains the known causal mismatch separately.

## M1-04 Association between Insulin Monotherapy versus Insulin plus Metformin and the Risk of All-Cause Mortality and Other Serious Outcomes: A Retrospective Cohort Study.

Source: https://pubmed.ncbi.nlm.nih.gov/27152598/ | PMID 27152598 | DOI 10.1371/journal.pone.0153594

Original label: same. Full-source decision: insufficient_evidence. Relationship-only decision: supported.

**Original claim**

People with type 2 diabetes treated with insulin plus metformin had a reduced risk of death and major cardiac events compared with people treated with insulin alone, according to University research.

**Decision and why**

The claim matches the conclusion, but the abstract reports materially different MACE results after propensity-score matching: 1.06 (0.75-1.49) before 1,275 days and 1.87 (1.22-2.86) afterward, versus 0.75 (0.62-0.91) in the other adjusted analysis. The complete source does not give one consistent basis for an unqualified lower-cardiac-risk summary.

Under the conservative whole-abstract rule, do not select only the favorable conclusion. This is not a finding that the publication is false. Explain the mixed results and withhold a certified minimal correction.

**Expected output**

Abstain. No reliable revised claim. Explain the source limitation and keep the original visible separately.

**Exact reference passages**

> Methods: For this retrospective cohort study, people with type 2 diabetes who progressed to insulin with or without metformin from 2000 onwards were identified from the UK Clinical Practice Research Datalink (≈7% sample of the UK population). The risks of all-cause mortality, MACE and incident cancer were evaluated using multivariable Cox models comparing insulin monotherapy with insulin plus metformin. We accounted for insulin dose.

Offsets 172 to 609 (end exclusive).

> Results: 12,020 subjects treated with insulin were identified, including 6,484 treated with monotherapy. There were 1,486 deaths, 579 MACE (excluding those with a history of large vessel disease), and 680 cancer events (excluding those in patients with a history of cancer). Corresponding event rates were 41.5 (95% CI 39.4-43.6) deaths, 20.8 (19.2-22.5) MACE, and 21.6 (20.0-23.3) cancer events per 1,000 person-years. The adjusted hazard ratios (aHRs) for people prescribed insulin plus metformin versus insulin monotherapy were 0.60 (95% CI 0.52-0.68) for all-cause mortality, 0.75 (0.62-0.91) for MACE, and 0.96 (0.80-1.15) for cancer. For patients who were propensity-score matched, the corresponding aHRs for all-cause mortality and cancer were 0.62 (0.52-0.75) and 0.99 (0.78-1.26), respectively. For MACE, the aHR was 1.06 (0.75-1.49) prior to 1,275 days and 1.87 (1.22-2.86) after 1,275 days post-index.

Offsets 610 to 1522 (end exclusive).

> Conclusions: People with type 2 diabetes treated with insulin plus concomitant metformin had a reduced risk of death and MACE compared with people treated with insulin monotherapy. There was no statistically significant difference in the risk of cancer between people treated with insulin as monotherapy or in combination with metformin.

Offsets 1523 to 1860 (end exclusive).

**Evidence sufficiency**

Include Results and Conclusions together; selecting only the conclusion would conceal the reason for abstention.

**Change from v1**

Removes this case from clean supported controls because the full abstract contains materially different cardiac-outcome results.

## M1-05 Testosterone treatment and risk of venous thromboembolism: population based case-control study.

Source: https://pubmed.ncbi.nlm.nih.gov/27903495/ | PMID 27903495 | DOI 10.1136/bmj.i5968

Original label: same. Full-source decision: overclaim. Relationship-only decision: supported.

**Original claim**

Starting testosterone treatment is associated with an increased risk of serious blood clots (known as venous thromboembolism or VTE) that peaks within six months and declines gradually thereafter, concludes a study in The BMJ today.

**Decision and why**

The association and timing match the source, but the studied population is men. This package adopts a conservative convention requiring explicit sex-specific and species-specific populations in general treatment statements. Add only "in men"; do not weaken the association.

This is a scope correction under our stated convention, not proof that the writer intended a universal claim. Report it separately from causal-strength editing and do not count it as an unchanged control.

**Expected output**

Starting testosterone treatment in men is associated with an increased risk of serious blood clots (known as venous thromboembolism or VTE) that peaks within six months and declines gradually thereafter, concludes a study in The BMJ today.

**Exact reference passages**

> Objective:  To determine the risk of venous thromboembolism associated with use of testosterone treatment in men, focusing particularly on the timing of the risk.

Offsets 0 to 162 (end exclusive).

> Participants:  19 215 patients with confirmed venous thromboembolism (comprising deep venous thrombosis and pulmonary embolism) and 909 530 age matched controls from source population including more than 2.22 million men between January 2001 and May 2013.

Offsets 367 to 622 (end exclusive).

> Results:  The adjusted rate ratio of venous thromboembolism was 1.25 (95% confidence interval 0.94 to 1.66) for current versus no testosterone treatment. In the first six months of testosterone treatment, the rate ratio of venous thromboembolism was 1.63 (1.12 to 2.37), corresponding to 10.0 (1.9 to 21.6) additional venous thromboembolisms above the base rate of 15.8 per 10 000 person years. The rate ratio after more than six months' treatment was 1.00 (0.68 to 1.47), and after treatment cessation it was 0.68 (0.43 to 1.07). Increased rate ratios within the first six months of treatment were observed in all strata: the rate ratio was 1.52 (0.94 to 2.46) for patients with pathological hypogonadism and 1.88 (1.02 to 3.45) for those without it, and 1.41 (0.82 to 2.41) for those with a known risk factor for venous thromboembolism and 1.91 (1.13 to 3.23) for those without one.

Offsets 1145 to 2029 (end exclusive).

> Conclusions:  Starting testosterone treatment was associated with an increased risk of venous thromboembolism, which peaked within six months and declined thereafter.

Offsets 2030 to 2196 (end exclusive).

**Evidence sufficiency**

The population appears in the Objective and Participants sections; the conclusion alone omits it.

**Change from v1**

Replaces the supported-control proposal with a population-only correction excluded from primary causal-correction counts.

## M1-06 Endonuclease G is a novel determinant of cardiac hypertrophy and mitochondrial function.

Source: https://pubmed.ncbi.nlm.nih.gov/21979051/ | PMID 21979051 | DOI 10.1038/nature10490

Original label: same. Full-source decision: supported. Relationship-only decision: supported.

**Original claim**

Scientists have found that the Endog gene in rats and mice influences the thickness of the muscular heart wall, how well the heart pumps and how much fat accumulates inside the organ.

**Decision and why**

The abstract links the rat Endog mutation to left ventricular mass and impaired cardiac function, and describes cell inhibition and mouse deletion experiments with enlarged, fatty cardiomyocytes. The claim preserves the rats and mice scope and uses "influences". Its stronger wording is supported relative to this abstract.

This is the control against weakening every causal phrase. Preserve the original wording and species restriction; the abstract does not establish the same mechanism or a treatment benefit in humans.

**Expected output**

Scientists have found that the Endog gene in rats and mice influences the thickness of the muscular heart wall, how well the heart pumps and how much fat accumulates inside the organ.

**Exact reference passages**

> Unbiased systems genetics approaches in the rat now provide a powerful complementary tool to genome-wide association studies, and we applied integrative genomics to dissect a highly replicated, blood-pressure-independent LVM locus on rat chromosome 3p.

Offsets 328 to 580 (end exclusive).

> Here we identified endonuclease G (Endog), which previously was implicated in apoptosis but not hypertrophy, as the gene at the locus, and we found a loss-of-function mutation in Endog that is associated with increased LVM and impaired cardiac function.

Offsets 581 to 834 (end exclusive).

> Inhibition of Endog in cultured cardiomyocytes resulted in an increase in cell size and hypertrophic biomarkers in the absence of pro-hypertrophic stimulation.

Offsets 835 to 994 (end exclusive).

> At baseline, the Endog-deleted mouse heart had depleted mitochondria, mitochondrial dysfunction and elevated levels of reactive oxygen species, which were associated with enlarged and steatotic cardiomyocytes.

Offsets 1355 to 1564 (end exclusive).

> Our study has further established the link between mitochondrial dysfunction, reactive oxygen species and heart disease and has uncovered a role for Endog in maladaptive cardiac hypertrophy.

Offsets 1565 to 1755 (end exclusive).

**Evidence sufficiency**

The aligned cell sentence alone does not cover the whole-heart claim. Keep the rat and mouse evidence together.

**Change from v1**

Keeps the supported causal control, with passages covering species and multiple outcomes.

## M1-07 Maternal use of oral contraceptives and risk of birth defects in Denmark: prospective, nationwide cohort study.

Source: https://pubmed.ncbi.nlm.nih.gov/26738512/ | PMID 26738512 | DOI 10.1136/bmj.h6712

Original label: same. Full-source decision: supported. Relationship-only decision: supported.

**Original claim**

Oral contraceptive use just before or during pregnancy is not associated with an increased risk of major birth defects, suggest the findings of a study published in The BMJ this week.

**Decision and why**

The full abstract supplies the birth-defect results and says exposure does not appear to be associated with increased risk. The claim says "not associated" and "suggest", rather than guaranteeing zero risk. Preserve it as a report of this study.

The aligned excerpt only discusses confounding and missing folate information. That excerpt is inadequate even though the full abstract supports the relationship. This is a source-sufficiency illustration, not a measured retrieval result.

**Expected output**

Oral contraceptive use just before or during pregnancy is not associated with an increased risk of major birth defects, suggest the findings of a study published in The BMJ this week.

**Exact reference passages**

> Methods: In a prospective observational cohort study, data on oral contraceptive use and major birth defects were collected among 880,694 live births from Danish registries between 1997 and 2011. We conservatively assumed that oral contraceptive exposure lasted up to the most recently filled prescription. The main outcome measure was the number of major birth defects throughout one year follow-up (defined according to the European Surveillance of Congenital Anomalies classification). Logistic regression estimated prevalence odds ratios of any major birth defect as well as categories of birth defect subgroups.

Offsets 135 to 751 (end exclusive).

> Study answer and limitations: Prevalence of major birth defects (per 1000 births) was consistent across each oral contraceptive exposure group (25.1, never users; 25.0, use >3 months before pregnancy onset (reference group); 24.9, use 0-3 months before pregnancy onset (that is, recent use); 24.8, use after pregnancy onset). No increase in prevalence of major birth defects was seen with oral contraceptive exposure among women with recent use before pregnancy (prevalence odds ratio 0.98 (95% confidence interval 0.93 to 1.03)) or use after pregnancy onset (0.95 (0.84 to 1.08)), compared with the reference group. There was also no increase in prevalence of any birth defect subgroup (for example, limb defects). It is unknown whether women took oral contraceptives up to the date of their most recently filled prescription. Also, the rarity of birth defects made disaggregation of the results difficult. Residual confounding was possible, and the analysis lacked information on folate, one of the proposed mechanisms.

Offsets 752 to 1773 (end exclusive).

> What this study adds: Oral contraceptive exposure just before or during pregnancy does not appear to be associated with an increased risk of major birth defects.

Offsets 1774 to 1935 (end exclusive).

**Evidence sufficiency**

Include findings and conclusion, retaining limitations. Never rewrite the relationship as "safe" or "no risk".

**Change from v1**

Keeps the full-abstract supported decision and explains the excerpt-only insufficiency.

## M1-08 Cognitive behavior therapy, exercise, or both for treating chronic widespread pain.

Source: https://pubmed.ncbi.nlm.nih.gov/22082706/ | PMID 22082706 | DOI 10.1001/archinternmed.2011.555

Original label: exaggerates. Full-source decision: overclaim. Relationship-only decision: supported.

**Original claim**

Talking therapy over the phone improves symptoms of chronic widespread pain

**Decision and why**

The full abstract describes random allocation and benefit on patient global assessment of change in health. The supplied results do not establish a specific pain-symptom improvement. Keep the treatment-effect wording but name the measured outcome, intervention and comparator.

Treat "symptoms" as an outcome-scope overclaim under the conservative measurement rule. This does not teach that randomized treatment-effect wording must become an association. It is an auxiliary scope example, excluded from primary causal-correction counts.

**Expected output**

Telephone-delivered cognitive behavioral therapy improved patient-rated overall health compared with treatment as usual in patients with chronic widespread pain.

**Exact reference passages**

> Methods: A total of 442 patients with CWP (meeting the American College of Rheumatology criteria) were randomized to receive 6 months of TCBT, graded exercise, combined intervention, or treatment as usual (TAU). The primary outcome, using a 7-point patient global assessment scale of change in health since trial enrollment (range: very much worse to very much better), was assessed at baseline and 6 months (intervention end) and 9 months after randomization. A positive outcome was defined as "much better" or "very much better." Data were analyzed using logistic regression according to the intention-to-treat principle.

Offsets 201 to 824 (end exclusive).

> Results: The percentages reporting a positive outcome at 6 and 9 months, respectively, were TAU group, 8% and 8%; TCBT group, 30% and 33%; exercise group, 35% and 24%; and combined intervention group, 37% and 37% (P < .001). After adjustment for age, sex, center, and baseline predictors of outcome, active interventions improved outcome compared with TAU: TCBT (6 months: odds ratio [OR], 5.0 [95% CI, 2.0-12.5]; 9 months: OR, 5.4 [95% CI, 2.3-12.8]), exercise (6 months: OR, 6.1 [95% CI, 2.5-15.1]; 9 months: OR, 3.6 [95% CI, 1.5-8.5]), and combined intervention (6 months: OR, 7.1 [95% CI, 2.9-17.2]; 9 months: OR, 6.2 [95% CI, 2.7-14.4]). At 6 and 9 months, combined intervention was associated with improvements in the 36-Item Short Form Health Questionnaire physical component score and a reduction in passive coping strategies. Conclusions on cost-effectiveness were sensitive to missing data.

Offsets 825 to 1725 (end exclusive).

> Conclusion: TCBT was associated with substantial, statistically significant, and sustained improvements in patient global assessment.

Offsets 1726 to 1859 (end exclusive).

**Evidence sufficiency**

Include randomization, the outcome definition and comparative results; the conclusion alone hides the distinction.

**Change from v1**

Resolves needs_discussion to an outcome-scope correction, separate from causal-strength editing.
