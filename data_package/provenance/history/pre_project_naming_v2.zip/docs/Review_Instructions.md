# Review workflow and handoff

Version 2.0 | October 15 2026

## Current state and reading routes

Eight AI-reviewed decisions are complete in annotations/reviewed_annotations.jsonl and .csv. Eight_Examples.md presents them with reasons and exact evidence. They are working calibration references, not teammate votes. Empty member forms and review/adjudication_log.csv intentionally represent human work not yet performed.

For onboarding, development or presentation, read the main handoff, Decision_Policy.md and Eight_Examples.md.

For independent review, first read only Annotation_Guide.md and the assigned member_N_independent_review.csv. Submit before reading the handoff, examples, annotations or decision log. Record prior_answer_exposure as none, exposed or uncertain. A previously exposed rating remains useful as an audit but is not blind independent evidence.

The form contains excerpt and full-abstract columns. Complete the excerpt judgment before reading the full abstract and record excerpt_before_full_abstract. This is a contextual diagnostic, not the primary whole-source decision. Future quantitative excerpt-versus-abstract studies should collect the first answer before revealing the second source in a separate step.

## Human validation later

Each case has two assigned reviewers. Fill a named person's form only with that person's actual judgment. Member 5 records initial labels and disagreement resolutions in the human adjudication log, including evidence scope and issue type. Do not call exposed answers independent or turn calibration cases into held-out tests after consensus. Fresh evaluation cases require two independent human judgments. Human review may revise an AI decision; preserve both versions and the reason.

## Owner handoffs

- Member 1 maintains IDs, the 44-candidate list and later paper-grouped splits.
- Member 2 recovers the remaining 36 candidate abstracts, verifies identity and passage sufficiency, and obtains human passage checks for gold evidence.
- Member 3 develops detection and fixed rules while keeping causal, scope-only and insufficient cases distinct.
- Member 4 implements revise, unchanged and abstain. Reference answers are outputs for development inspection, never evaluation prompt inputs.
- Member 5 creates ratings under the evidence policy and reports actual denominators and reviewer provenance.
- Member 6 uses M1-01 for correction, M1-06 for preservation and M1-03 for abstention, explicitly labeled AI-reviewed calibration.

See Team_Plan_Update.md and provenance/pilot_plan.json for exact acquisition and split rules.
