# Member 1 midterm data package

Version 2.0 | October 15 2026

The Scientific Overclaim Editor compares a draft claim with its supplied source, makes the smallest supported correction, preserves supported claims and abstains when a reliable correction cannot be justified. This package now contains eight completed AI-reviewed calibration decisions and a concrete 44-candidate acquisition list. Human validation and model experiments remain separate future work.

## Choose your reading route

**Onboarding, development or presentation:** start with docs/Member1_Midterm_Handoff.docx. It explains the decisions, why they were chosen, the evidence rule, the pilot and owner handoffs. Decision_Policy.md, Eight_Examples.md and Team_Plan_Update.md provide the same policy and details in plain text.

**Independent human review before seeing answers:** first read only docs/Annotation_Guide.md and the assigned review/member_N_independent_review.csv. Submit before reading the handoff, examples, annotations or decision log. Record any prior exposure. An exposed review is an audit, not a blind independent judgment.

## Completed work

- Preserved original data: 100 train pairs, 563 reserved test pairs, all 18 upstream README/data files and two auxiliary strength files.
- Eight real training inputs with full abstracts, PMID/DOI provenance and exact evidence offsets.
- Eight AI-reviewed working references: 3 overclaims (1 causal and 2 scope-only), 3 supported claims and 2 abstentions. These are calibration categories, not performance results.
- A deterministic acquisition queue: 22 originally exaggerates and 22 originally same pairs, including all eight calibration cases.
- An evidence policy, team-plan update, data dictionary, six unfilled human-review forms and preserved version history.

## Which annotations to use

annotations/reviewed_annotations.jsonl and its CSV mirror are the current working references. The assistant determined them at the user's request. Human count remains zero and human fields remain empty. Older ai_draft_annotations files are unchanged historical v1 proposals, not current answers.

Use only supplied evidence. Missing scientific quantities require abstention rather than guessed preservation or silent deletion. Report scope-only corrections separately from causal-strength corrections. See docs/Decision_Policy.md.

## Adopted pilot

Only 22 original training examples have the exaggerates label. Replace the former 30-overclaim starting target with the 44-candidate pool in data/pilot_candidates. Eight abstracts are recovered and 36 remain. Aim for approximately 20 development and up to 24 evaluation inputs after source recovery, relabeling, exclusions and paper grouping. No evaluation split is frozen. All eight calibration inputs are locked to development. The proposal's 150-250 target is a stretch goal requiring additional collection.

The original test file remains reserved. Aggregate ID/text overlap checks passed; a complete paper-identity audit is pending. Alternate PET files, auxiliary strength data and unlabeled sentences are not additional paired editing examples.

## Files and commands

raw/ and sources/ preserve source data. data/ holds inputs and acquisition IDs. annotations/reviewed_annotations holds current AI references. review/ holds an AI decision log and separate unfilled human records. docs/ explains choices. provenance/ records versions, audit, plan, history and checksums.

Run python scripts/verify_package.py to validate integrity, evidence offsets, actions, pilot selection and provenance. Run python scripts/load_examples.py for model inputs. Use --show-reference only to inspect development answers, not as an evaluation input path.

CSV uses UTF-8 with a byte-order mark; JSONL uses UTF-8. Consult docs/Data_Dictionary.md before integration.

## Attribution

Wright and Augenstein (2021): https://aclanthology.org/2021.emnlp-main.845/
Official repository: https://github.com/copenlu/scientific-exaggeration-detection
Auxiliary data: https://github.com/junwang4/correlation-to-causation-exaggeration
Abstract records and recorded article license information: sources/abstracts.jsonl.
The previously downloaded dataset card lists GPL-3.0; the pinned GitHub snapshot has no standalone LICENSE file. Original text remains attributed to its authors. Readable abstracts normalize HTML and whitespace only.
