# Member 1 content for the two slides

## Completed progress for slide 2

Downloaded and audited the official paired dataset: 100 training examples and 563 held-out test examples. Prepared eight real training pairs for annotation calibration and recovered complete abstracts for all eight. Created an annotation guide and independent review forms.

## Main data takeaway

The provided source conclusion is not always enough to judge a claim. Original strength labels also do not establish editing correctness. We will check source sufficiency and retain supported controls before treating examples as correction targets.

## Specific supporting observation

M1-07 is labeled `same`, but its aligned source excerpt only discusses confounding and missing folate data. The relevant result appears elsewhere in the full abstract. This is a concrete evidence-sufficiency example, not a measured retrieval result.

## Suggested slide 1 illustration

M1-01: the press release says the referral pathway “is saving lives.” The study is a cohort analysis that reports a mortality association and describes efficacy conditionally. Show the source, mark the phrase, and label any displayed correction as a proposed edit rather than a tested model output.

## Remaining work

Teammates independently review the examples; Member 2 verifies candidate evidence; Member 5 adjudicates project labels. Then expand the data and compare corrections with gold evidence before using automatically selected evidence. The sample is not final test data and has no system accuracy result.

## Optional brief spoken update

We downloaded the original dataset and prepared eight real examples with full abstracts. Our data inspection shows that an aligned conclusion can omit evidence needed to judge the claim. We therefore need to check source sufficiency and review labels before evaluating corrections. Team annotation and model experiments remain to be completed.
