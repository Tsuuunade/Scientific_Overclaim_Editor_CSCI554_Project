# Data dictionary

## Upstream paired data

Each raw JSONL line is one paired abstract and press-release conclusion. Fields are preserved exactly.

| Field | Meaning |
|---|---|
| original_file_id | Original Sumner or Bratton spreadsheet identifier; not a DOI or PMID |
| press_release_conclusion | Draft claim drawn from a press release |
| press_release_strength | Original wording strength code |
| abstract_conclusion | Pre-aligned source conclusion sentence or excerpt |
| abstract_strength | Original source wording strength code |
| exaggeration_label | same, exaggerates, or downplays, based on relative wording strength |

Strength codes: 0 no relationship, 1 correlation, 2 conditional causation, 3 causation. These describe wording, not independent validation of a causal study design.

## Prepared examples

| Field | Meaning |
|---|---|
| example_id | Stable calibration ID M1-01 through M1-08 |
| source_record_key | Original filename namespace plus original_file_id |
| raw_row_1based | One-based row number in the original training JSONL |
| original_split | Always train for these examples |
| project_use | midterm_calibration_only; exclude from final held-out claims |
| paper_group_id | Recovered PMID used to keep the selected paper together |
| pmid and doi | Verified publication identifiers from the matching abstract record |
| original_claim | Unchanged press_release_conclusion |
| aligned_abstract_conclusion | Unchanged pre-aligned abstract_conclusion |
| original_exaggeration_label | Original label retained separately from project judgments |
| original_press_release_strength and original_abstract_strength | Original strength codes |
| source_text | Complete abstract with HTML removed and whitespace normalized |
| source_text_path | Path to readable source text including metadata |
| annotation_status | pending_human_review until team review is complete |

## AI draft annotations

`draft_label_aligned_excerpt` and `draft_label_full_abstract` are separate provisional judgments. `candidate_evidence` contains exact quotes and zero-based, end-exclusive offsets into `source_text`. `draft_problematic_phrase` and its offsets refer to `original_claim`. Empty spans mean no edit has been proposed. A discussion span can identify an issue to inspect without establishing a final overclaim.

`draft_correction` contains a proposed revision or the unchanged original for supported candidates. A blank value on a discussion case is intentional. `conditional_correction_for_discussion` is an optional narrowing to consider after adjudication. No AI suggestion is an accepted correction reference.

`human_final_label`, `human_gold_evidence`, and `human_final_correction` remain empty. `human_review_count` is zero. Human forms store the reviewers' own answers separately.

## Later project annotation schema

For a larger pilot retain example ID, verified paper ID, original claim, source text and scope, original label, final project label, exact problematic phrase, gold evidence passages with offsets, acceptable correction, rationale, reviewer identities, disagreement resolution, and project split. Freeze the project split only after checking verified paper identities. Do not treat missing IDs as distinct papers by default.
