# Annotation guide

## Task and evidence scope

Judge whether a draft claim is stronger than the supplied scientific source supports. Focus on causal wording. Record population, outcome, quantity, or other factual mismatches separately. Evaluate the aligned excerpt and the full abstract independently; the answer can change with the evidence provided.

## Labels

- **overclaim**: relevant evidence is sufficient and the draft asserts a stronger relationship or greater certainty. For example, an association becomes a definite causal effect.
- **supported**: the supplied evidence supports the relationship and its qualifications. Strong causal words can be supported by an appropriate source. Preserve the claim unless another substantive error is identified.
- **insufficient_evidence**: the supplied passage does not address the relevant finding or omits context needed for a decision. Do not treat missing support as proof of exaggeration.
- **needs_discussion**: temporary annotation status for competing interpretations. Record why. Resolve to a task label or retain as unscored ambiguity before evaluation.

## Review steps

1. Read the original claim. Identify the exposure or intervention, population, outcome, relationship, and qualifications.
2. Read the aligned excerpt alone and assign its label. Then read the complete abstract and assign a separate label. Note any change and its cause.
3. Select exact evidence for the relationship and any design or scope information needed to judge it. Include multiple passages when one sentence is insufficient.
4. If overclaiming is clear, mark the shortest problematic phrase and propose the smallest supported edit. Preserve supported details and avoid new information.
5. If supported, copy the original claim unchanged. If evidence is insufficient or the case needs discussion, leave the correction blank and explain what is missing or disputed.

## Difficult cases

The benchmark's `same` label compares language-strength categories; it is not a factual-preservation guarantee. Likewise, `exaggerates` is the original benchmark label, not an automatically accepted editing target. Do not overwrite it.

Study design provides context. An observational study does not automatically make every causal sentence an overclaim relative to its abstract, which may itself contain causal speculation. A randomized study also does not justify every outcome or population claim. Our primary target is support relative to the source; broader scientific validity is a separate question.

“May cause” is still a causal claim. “Not associated” is not a guarantee of zero risk. “Predicts” can describe a statistical prediction without establishing causation. Preserve the original meaning when deciding whether an edit is necessary.

## Independent review

Two teammates review each pair before seeing AI suggestions or each other's answers. Fill in the assigned CSV, including exact evidence, rationale, and uncertainty. Then compare answers and record resolutions in `review/adjudication_log.csv`. Gold labels require both reviews and adjudication of disagreements. Do not score this calibration sample as test performance.
