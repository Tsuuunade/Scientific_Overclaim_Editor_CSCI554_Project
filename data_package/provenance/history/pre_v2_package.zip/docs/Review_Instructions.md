# Independent review and handoff

## Suggested short team session

Each member first reviews their assigned examples independently. Use the CSV fields for the excerpt decision, complete abstract decision, exact evidence, revision, and rationale. The original labels and AI suggestions are intentionally absent from these forms. Reviewers should inspect the aligned excerpt before reading the full abstract; do not use remembered full-abstract details to justify an excerpt-only decision.

Each pair has two assigned reviewers. Members 1, 2, 4, and 5 review three pairs each; Members 3 and 6 review two pairs each. Member 1 coordinates the comparison. No reviews are currently completed.

After the independent pass, use a 20–30 minute discussion to resolve disagreements. Start with M1-01 and M1-06 to contrast correction and preservation. Then discuss M1-07 for missing evidence, followed by M1-02 and M1-08 for source-context ambiguities. Review the remaining pairs and save resolutions. Do not require forced consensus when the source remains inadequate.

## Handoffs

- Member 2: verify the fetched abstract matches, candidate passages, and whether one passage is sufficient. These are candidates for gold evidence, not completed human gold annotations.
- Members 3 and 4: use the eight examples for development and demonstrations. `data/train_original_labels.jsonl` contains all 100 original training pairs for later method work. Do not tune on the original test file.
- Member 5: finalize the annotation criteria, collect independent judgments, and adjudicate. Preserve original labels even if the project label differs.
- Member 6: use M1-01 as a candidate illustration and the observed dataset limitations as slide 2 progress. No numerical model-quality claim follows from this work.

## A feasible later pilot

There are 22 original training overclaims and 61 `same` pairs. A 44-pair pilot with 22 from each category is a feasible candidate pool, not 44 verified editing examples. A provisional 20-development/24-evaluation split could be balanced 10/10 and 12/12, subject to source recovery and relabeling. Include the eight calibration examples in development. Group by verified paper identity and recalculate balance after human adjudication. Additional annotated sources are needed to reach the original 150–250 project target without repurposing the benchmark test set.

The files in `pet_cls` and `pet_nli` are alternate representations of the same training data. The 94,920 unlabeled sentences are not 94,920 labeled overclaim examples. The auxiliary strength files are also a different task. Do not add these counts to the 663 paired examples.
