# Eight examples for team discussion

These are real pairs selected from the original training split. They are a purposive calibration sample, not a benchmark. Read the independent review forms before these AI suggestions. Complete abstracts are in `sources/abstracts/`.

## M1-01 Urgent cancer referrals
- Original record: 25-002, training row 1.
- Source: Use of the English urgent referral pathway for suspected cancer and mortality in patients with cancer: cohort study. https://pubmed.ncbi.nlm.nih.gov/26462713/
- Original label: exaggerates. Strengths: press 3, abstract 2.
- Selection purpose: Clear overclaim candidate.
- Draft labels: excerpt **overclaim**; full abstract **overclaim**.

**Original claim**
Use of the urgent referral pathway (often called the two week wait system) by general practices for patients with suspected cancer is saving lives, according to a study in The BMJ this week.

**Original aligned excerpt**
Use of the urgent referral pathway could be efficacious.

**AI rationale**
The claim asserts lives are being saved. The abstract reports a mortality association and describes efficacy conditionally. Replace the definite causal assertion while retaining the referral pathway, patient context, and attribution.

**Discussion**
Use as the main slide example. A model output has not been tested; the proposed correction is an AI draft.

**Proposed output after full abstract review**
Use of the urgent referral pathway (often called the two week wait system) by general practices for patients with suspected cancer was associated with lower mortality among patients with cancer, according to a study in The BMJ this week.

## M1-02 Psychological treatment preferences
- Original record: 26-002, training row 3.
- Source: Patient preference in psychological treatment and associations with self-reported outcome: national cross-sectional survey in England and Wales. https://pubmed.ncbi.nlm.nih.gov/26768890/
- Original label: exaggerates. Strengths: press 2, abstract 1.
- Selection purpose: Context dependent discussion case.
- Draft labels: excerpt **overclaim**; full abstract **needs_discussion**.

**Original claim**
Meeting patients' preferences for the time and place of their psychological treatment may affect their perception of treatment outcome, a cross-sectional survey by researchers from the Royal College of Psychiatrists and Imperial College London involving 14,587 respondents suggests.

**Original aligned excerpt**
People who reported preferences that were not met were less likely to state that treatment had helped them with their problems.

**AI rationale**
The aligned excerpt is associational. However, the full abstract itself concludes that meeting preferences may improve outcomes. The press release also uses a conditional hedge. Team adjudication must decide how to handle speculation already present in the source. Do not call it a definite overclaim solely from the selected excerpt.

**Discussion**
Keep the original exaggerates label. Decide whether source-relative support or methodological causal justification is the project target; these are different tasks.

## M1-03 Brain growth across mammal species
- Original record: 16-11-002-1, training row 95.
- Source: Maternal investment, life histories, and the costs of brain growth in mammals. https://pubmed.ncbi.nlm.nih.gov/21444808/
- Original label: exaggerates. Strengths: press 3, abstract 1.
- Selection purpose: Clear overclaim candidate.
- Draft labels: excerpt **overclaim**; full abstract **overclaim**.

**Original claim**
The study of 128 mammal species, including humans, shows that brain growth in babies is determined by the duration of pregnancy and how long they suckle.

**Original aligned excerpt**
In support of the developmental cost hypothesis, we show that evolutionary changes in pre- and postnatal brain growth correlate specifically with duration of the relevant phases of maternal investment (gestation and lactation, respectively).

**AI rationale**
The source describes correlations between developmental phases and maternal investment. The claim changes that relationship to determination. A local replacement preserves the source-relative association. The count of 128 species is in the original claim and is confirmed in the linked paper methods, but not stated in the abstract.

**Discussion**
Check that gestation and lactation remain aligned with prenatal and postnatal growth. Do not turn this comparative finding into individual-level advice.

**Proposed output after full abstract review**
The study of 128 mammal species, including humans, shows that brain growth in babies is correlated with the duration of pregnancy and how long they suckle.

## M1-04 Insulin and metformin
- Original record: 04-008, training row 23.
- Source: Association between Insulin Monotherapy versus Insulin plus Metformin and the Risk of All-Cause Mortality and Other Serious Outcomes: A Retrospective Cohort Study. https://pubmed.ncbi.nlm.nih.gov/27152598/
- Original label: same. Strengths: press 1, abstract 1.
- Selection purpose: Supported association control candidate.
- Draft labels: excerpt **supported**; full abstract **supported**.

**Original claim**
People with type 2 diabetes treated with insulin plus metformin had a reduced risk of death and major cardiac events compared with people treated with insulin alone, according to University research.

**Original aligned excerpt**
People with type 2 diabetes treated with insulin plus concomitant metformin had a reduced risk of death and MACE compared with people treated with insulin monotherapy.

**AI rationale**
The original claim reports a difference in risk between observed treatment groups, matching the abstract conclusion without asserting that metformin causes the difference. Preserve the population, comparator, death outcome, and cardiac outcome.

**Discussion**
The full abstract includes sensitivity to propensity-score matching for MACE. Confirm the intended scope of the summary during human review; do not upgrade it to a randomized treatment effect.

**Proposed output after full abstract review**
People with type 2 diabetes treated with insulin plus metformin had a reduced risk of death and major cardiac events compared with people treated with insulin alone, according to University research.

## M1-05 Testosterone and blood clot risk
- Original record: 25-143, training row 32.
- Source: Testosterone treatment and risk of venous thromboembolism: population based case-control study. https://pubmed.ncbi.nlm.nih.gov/27903495/
- Original label: same. Strengths: press 1, abstract 1.
- Selection purpose: Supported association control candidate.
- Draft labels: excerpt **supported**; full abstract **supported**.

**Original claim**
Starting testosterone treatment is associated with an increased risk of serious blood clots (known as venous thromboembolism or VTE) that peaks within six months and declines gradually thereafter, concludes a study in The BMJ today.

**Original aligned excerpt**
Starting testosterone treatment was associated with an increased risk of venous thromboembolism, which peaked within six months and declined thereafter.

**AI rationale**
The claim preserves the association, timing within six months, and later decline reported in the source conclusion. An automatic weakening rule should not change this supported relationship.

**Discussion**
The study population is men. Review population scope if the final rubric treats omitted population qualifications as an error; this is not a newly verified universal claim.

**Proposed output after full abstract review**
Starting testosterone treatment is associated with an increased risk of serious blood clots (known as venous thromboembolism or VTE) that peaks within six months and declines gradually thereafter, concludes a study in The BMJ today.

## M1-06 Endog gene and heart changes
- Original record: 07-11-035-1, training row 31.
- Source: Endonuclease G is a novel determinant of cardiac hypertrophy and mitochondrial function. https://pubmed.ncbi.nlm.nih.gov/21979051/
- Original label: same. Strengths: press 3, abstract 3.
- Selection purpose: Supported stronger causal control candidate.
- Draft labels: excerpt **insufficient_evidence**; full abstract **supported**.

**Original claim**
Scientists have found that the Endog gene in rats and mice influences the thickness of the muscular heart wall, how well the heart pumps and how much fat accumulates inside the organ.

**Original aligned excerpt**
Inhibition of Endog in cultured cardiomyocytes resulted in an increase in cell size and hypertrophic biomarkers in the absence of pro-hypertrophic stimulation.

**AI rationale**
The complete abstract includes experimental inhibition and gene deletion, together with rat and mouse findings. Stronger wording about influence can be supported within that experimental scope. The aligned cell sentence alone does not cover every whole-heart outcome in the original claim.

**Discussion**
This is the strongest control against blanket causal weakening. Preserve rats and mice. Do not generalize the finding to humans.

**Proposed output after full abstract review**
Scientists have found that the Endog gene in rats and mice influences the thickness of the muscular heart wall, how well the heart pumps and how much fat accumulates inside the organ.

## M1-07 Oral contraceptives and birth defects
- Original record: 25-027, training row 5.
- Source: Maternal use of oral contraceptives and risk of birth defects in Denmark: prospective, nationwide cohort study. https://pubmed.ncbi.nlm.nih.gov/26738512/
- Original label: same. Strengths: press 0, abstract 0.
- Selection purpose: Insufficient excerpt with useful full context.
- Draft labels: excerpt **insufficient_evidence**; full abstract **supported**.

**Original claim**
Oral contraceptive use just before or during pregnancy is not associated with an increased risk of major birth defects, suggest the findings of a study published in The BMJ this week.

**Original aligned excerpt**
Residual confounding was possible, and the analysis lacked information on folate, one of the proposed mechanisms.

**AI rationale**
The dataset excerpt reports confounding and missing folate information. It cannot independently support the claimed absence of an increased risk. The complete abstract supplies relevant results and the main conclusion. Keep “not associated” distinct from a guarantee of no risk.

**Discussion**
Best illustration of an evidence sufficiency failure. With only the supplied aligned excerpt, abstain or request more context. With the full abstract, the association wording is a supported control candidate.

**Proposed output after full abstract review**
Oral contraceptive use just before or during pregnancy is not associated with an increased risk of major birth defects, suggest the findings of a study published in The BMJ this week.

## M1-08 Telephone therapy for widespread pain
- Original record: 12-11-028-1, training row 14.
- Source: Cognitive behavior therapy, exercise, or both for treating chronic widespread pain. https://pubmed.ncbi.nlm.nih.gov/22082706/
- Original label: exaggerates. Strengths: press 3, abstract 1.
- Selection purpose: Trial context and outcome discussion case.
- Draft labels: excerpt **overclaim**; full abstract **needs_discussion**.

**Original claim**
Talking therapy over the phone improves symptoms of chronic widespread pain

**Original aligned excerpt**
TCBT was associated with substantial, statistically significant, and sustained improvements in patient global assessment.

**AI rationale**
The original pair is labeled exaggerates because the selected conclusion uses association language. The complete abstract reports random allocation and treatment effects. Therefore causal wording alone does not establish exaggeration. The remaining issue is whether “symptoms” overstates the measured patient global assessment outcome.

**Discussion**
Discuss the outcome mismatch before relabeling. The proposed narrower sentence is conditional on team adjudication; it is not a gold correction.

**Conditional narrower output for discussion**
Telephone-delivered cognitive behavioral therapy improved patient-rated overall health compared with treatment as usual in patients with chronic widespread pain.
