# Member 1 midterm data preparation

The official data are downloaded and eight real training examples are prepared for team calibration. Complete abstracts have been recovered for all eight. Start with `docs/Member1_Midterm_Handoff.docx` and the one-page guide in `docs/Annotation_Guide.md`.

## What is ready

- Original labeled data: 100 training pairs and 563 test pairs, preserved unchanged.
- All 18 data and README files from the authors' pinned repository snapshot, including 94,920 unlabeled sentences and their aligned internal IDs.
- Two auxiliary claim-strength files referenced by the authors' download script. These are separate classification data, not additional paired correction examples.
- Eight examples, original labels, source identifiers, complete abstracts, and proposed evidence spans.
- AI draft annotations, blank independent review forms for six members, and an adjudication log.
- Data audit, provenance, SHA-256 hashes, and scripts to verify the package or redownload sources.

## Open these files in order

1. `docs/Member1_Midterm_Handoff.docx`: completed work, findings, review instructions, and presentation handoff.
2. `docs/Annotation_Guide.md`: the labeling rules.
3. Your assigned file in `review/member_N_independent_review.csv`: fill in judgments without consulting AI drafts first.
4. `docs/Eight_Examples.md`: original claims, source links, and AI discussion notes. Read after your first independent pass.
5. `data/midterm_examples.jsonl`: full machine-readable sample. `data/midterm_examples_index.csv` is the compact index.

## Important findings

Only 22 training pairs have the original `exaggerates` label. The earlier proposed 30-overclaim training-only sample is therefore unavailable from this split. Start with up to 22 candidate overclaims plus 22 candidate controls if a balanced pilot is wanted. Include these calibration examples in development, then divide the remaining pairs by verified paper identity. Counts and balance must be reconsidered after human review.

The original labels compare language strength. `same` does not establish complete factual support. Some source excerpts omit decisive results or design context. Preserve original labels and store new project judgments separately.

## What is still pending

No teammate has independently reviewed these files yet. All supplied evidence selections, revised claims, and project labels are AI drafts. The human gold fields are empty. The reserved test set has not been used for example selection or model tuning. Aggregate integrity checks inspected it programmatically; this does not establish a full paper-level leakage audit.

## Folder guide

- `raw/`: unchanged upstream files. Do not edit.
- `sources/`: fetched abstract records and readable text, with PMID and DOI provenance.
- `data/`: prepared training data and the eight calibration examples.
- `annotations/`: AI proposals kept separate from original data and human labels.
- `review/`: human input forms and assignments.
- `provenance/`: source versions, counts, and hashes.
- `scripts/`: standard-library Python utilities. No model, API key, GPU, or package installation is needed to load the data.

## Use the files

Unzip the package, open a terminal in its top-level folder, and run:

```bash
python3 scripts/verify_package.py
python3 scripts/load_examples.py
```

The CSV files use UTF-8 with a byte-order mark for Excel compatibility. JSONL files use UTF-8. If a spreadsheet program places everything in one column, import the CSV with comma as delimiter.

## Sources

Wright and Augenstein (2021), https://aclanthology.org/2021.emnlp-main.845/
Official repository: https://github.com/copenlu/scientific-exaggeration-detection
Dataset card: https://huggingface.co/datasets/copenlu/scientific-exaggeration-detection
Auxiliary data: https://github.com/junwang4/correlation-to-causation-exaggeration
Full abstracts: Europe PMC core records linked to the PubMed identifiers in `sources/abstracts.jsonl`.

Original text is attributed to its authors. The Hugging Face dataset card lists GPL-3.0. The GitHub snapshot has no standalone LICENSE file. Per-article license metadata, when supplied by Europe PMC, is retained in the abstract index. Source text is unchanged apart from HTML removal and whitespace normalization in readable abstract copies.
