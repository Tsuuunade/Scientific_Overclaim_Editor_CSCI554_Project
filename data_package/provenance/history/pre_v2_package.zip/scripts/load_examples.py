from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
path = ROOT/'data/midterm_examples.jsonl'
examples = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]
for example in examples:
    print(example['example_id'], example['original_file_id'], example['pmid'])
    print('Claim:', example['original_claim'])
    print('Source:', example['source_url'])
    print('Abstract characters:', len(example['source_text']))
    print()

# For later detector development, load data/train_original_labels.jsonl.
# Keep raw/.../insciout_test.jsonl reserved for final evaluation.
