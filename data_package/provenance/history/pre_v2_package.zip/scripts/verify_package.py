from pathlib import Path
import collections, csv, hashlib, json, re, unicodedata

ROOT = Path(__file__).resolve().parents[1]
def rows(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]
def norm(value):
    return re.sub(r'\W+', '', unicodedata.normalize('NFKC', value).lower())

def main():
    checked = 0
    for name in ['download_manifest.json', 'auxiliary_strength_manifest.json']:
        manifest = json.loads((ROOT/'provenance'/name).read_text())
        for item in manifest['files']:
            path = ROOT/item['local_path']
            assert hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256'], f'Changed raw file: {path}'
            checked += 1
    train = rows(ROOT/'raw/wright_augenstein_2021/data/insciout_train.jsonl')
    test = rows(ROOT/'raw/wright_augenstein_2021/data/insciout_test.jsonl')
    assert len(train) == 100 and len(test) == 563
    assert collections.Counter(r['exaggeration_label'] for r in train) == {'same': 61, 'exaggerates': 22, 'downplays': 17}
    assert collections.Counter(r['exaggeration_label'] for r in test) == {'same': 345, 'exaggerates': 122, 'downplays': 96}
    for field in ['original_file_id', 'abstract_conclusion', 'press_release_conclusion']:
        assert not ({norm(r[field]) for r in train} & {norm(r[field]) for r in test}), field
    original = {r['original_file_id']: r for r in train}
    examples = rows(ROOT/'data/midterm_examples.jsonl')
    drafts = rows(ROOT/'annotations/ai_draft_annotations.jsonl')
    assert len(examples) == len(drafts) == 8
    assert len({r['pmid'] for r in examples}) == 8
    abstracts = {r['example_id']: r for r in rows(ROOT/'sources/abstracts.jsonl')}
    for e, d in zip(examples, drafts):
        assert e['example_id'] == d['example_id']
        raw = original[e['original_file_id']]
        assert e['original_claim'] == raw['press_release_conclusion']
        assert e['aligned_abstract_conclusion'] == raw['abstract_conclusion']
        assert e['original_exaggeration_label'] == raw['exaggeration_label']
        assert e['original_split'] == 'train' and e['project_use'] == 'midterm_calibration_only'
        assert e['source_text'] == abstracts[e['example_id']]['abstract_text']
        assert norm(e['aligned_abstract_conclusion']) in norm(e['source_text']), e['example_id']
        a = abstracts[e['example_id']]
        assert hashlib.sha256((ROOT/a['raw_response_path']).read_bytes()).hexdigest() == a['raw_response_sha256']
        for passage in d['candidate_evidence']:
            assert e['source_text'][passage['start_char']:passage['end_char']] == passage['quote']
        if d['draft_problematic_phrase']:
            assert e['original_claim'][d['draft_span_start']:d['draft_span_end']] == d['draft_problematic_phrase']
    with (ROOT/'review/review_assignments.csv').open(encoding='utf-8-sig', newline='') as f:
        assignments = list(csv.DictReader(f))
    assert collections.Counter(r['example_id'] for r in assignments) == {e['example_id']: 2 for e in examples}
    audit = json.loads((ROOT/'provenance/data_audit.json').read_text())
    assert audit['recovered_complete_abstracts'] == 8
    print(f'Raw checksums verified: {checked} upstream data/README files plus 8 abstract responses')
    print('Paired data: 100 train and 563 test; original labels preserved')
    print('Calibration sample: 8 training examples, 8 distinct PMIDs, 8 matching complete abstracts')
    print('Candidate evidence and phrase offsets verified; two reviewers assigned per example')
    print('This is file integrity verification, not human annotation or model evaluation.')

if __name__ == '__main__':
    main()
